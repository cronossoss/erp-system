<!DOCTYPE html>
<html>

<head>
    <title>Edit zaposlenog</title>
</head>

<body>

    <h1>Edit zaposlenog</h1>

    <a href="<?php echo e(route('employees.index')); ?>">← Nazad</a>

    <?php if($errors->any()): ?>
    <div style="color:red;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('employees.update', $employee->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Ime:</label><br>
        <input type="text" name="first_name" value="<?php echo e($employee->first_name); ?>"><br><br>

        <label>Prezime:</label><br>
        <input type="text" name="last_name" value="<?php echo e($employee->last_name); ?>"><br><br>

        <label>Pozicija:</label><br>
        <input type="text" name="position" value="<?php echo e($employee->position); ?>"><br><br>

        <label>Organizaciona jedinica:</label><br>
        <select name="organizational_unit_id">
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unit->id); ?>"
                <?php echo e($employee->organizational_unit_id == $unit->id ? 'selected' : ''); ?>>
                <?php echo e($unit->name); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <button type="submit">Sačuvaj izmene</button>
    </form>

</body>

</html><?php /**PATH C:\laragon\www\erp\resources\views/employees/edit.blade.php ENDPATH**/ ?>