<!DOCTYPE html>
<html>

<head>
    <title>Dodaj zaposlenog</title>
</head>

<body>

    <h1>Dodaj zaposlenog</h1>

    <a href="<?php echo e(route('employees.index')); ?>">← Nazad</a>

    <?php if($errors->any()): ?>
    <div style="color:red;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('employees.store')); ?>">
        <?php echo csrf_field(); ?>

        <label>Ime:</label><br>
        <input type="text" name="first_name"><br><br>

        <label>Prezime:</label><br>
        <input type="text" name="last_name"><br><br>

        <label>Pozicija:</label><br>
        <input type="text" name="position"><br><br>

        <label>Organizaciona jedinica:</label><br>
        <select name="organizational_unit_id">
            <option value="">-- izaberi --</option>
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <button type="submit">Sačuvaj</button>
    </form>

</body>

</html><?php /**PATH C:\laragon\www\erp\resources\views/employees/create.blade.php ENDPATH**/ ?>