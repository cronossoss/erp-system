<div id="overlay" class="hidden fixed inset-0 bg-black bg-opacity-50 z-40"></div>

<!-- ADD -->
<div id="modal" class="hidden fixed inset-0 flex items-center justify-center z-50">
<div class="bg-white p-6 rounded w-96">

<h3 class="text-lg font-bold mb-3">Dodaj zaposlenog</h3>

<input id="employee_number" placeholder="Matični broj (5 cifara)"
class="w-full border px-3 py-2 mb-2">

<input id="first_name" placeholder="Ime" class="w-full border px-3 py-2 mb-2">
<input id="last_name" placeholder="Prezime" class="w-full border px-3 py-2 mb-2">
<input id="position" placeholder="Pozicija" class="w-full border px-3 py-2 mb-2">

<select id="contract_type" class="w-full border px-3 py-2 mb-2">
<option value="">-- Ugovor --</option>
<option value="neodređeno">Neodređeno</option>
<option value="određeno">Određeno</option>
<option value="drugo">Drugo</option>
</select>

<div class="flex gap-2 mb-4">
    <select id="unit_select" class="w-full border px-3 py-2">
        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button onclick="openUnitModal()"
        class="bg-green-500 text-white px-3 rounded">
        +
    </button>
</div>

<div class="flex justify-end gap-2">
<button onclick="closeModal()">Zatvori</button>
<button onclick="saveEmployee()" class="bg-blue-600 text-white px-4 py-2 rounded">
Sačuvaj
</button>
</div>

</div>
</div>

<!-- EDIT -->
<div id="editModal" class="hidden fixed inset-0 flex items-center justify-center z-50">
<div class="bg-white p-6 rounded w-96">

<input type="hidden" id="edit_id">

<h3 class="text-lg font-bold mb-3">Izmena zaposlenog</h3>

<input id="edit_employee_number" placeholder="Matični broj"
class="w-full border px-3 py-2 mb-2">

<input id="edit_first_name" placeholder="Ime"
class="w-full border px-3 py-2 mb-2">

<input id="edit_last_name" placeholder="Prezime"
class="w-full border px-3 py-2 mb-2">

<input id="edit_position" placeholder="Pozicija"
class="w-full border px-3 py-2 mb-2">

<select id="edit_contract_type" class="w-full border px-3 py-2 mb-2">
    <option value="">-- Ugovor --</option>
    <option value="neodređeno">Neodređeno</option>
    <option value="određeno">Određeno</option>
    <option value="drugo">Drugo</option>
</select>

<input type="date" id="edit_contract_end_date"
class="w-full border px-3 py-2 mb-2">

<div class="flex gap-2 mb-4">
    <select id="edit_unit_select" class="w-full border px-3 py-2">
        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button onclick="openUnitModal()"
        class="bg-green-500 text-white px-3 rounded">
        +
    </button>
</div>

<div class="flex justify-end gap-2">
<button onclick="closeEditModal()">Zatvori</button>
<button onclick="updateEmployee()" class="bg-blue-600 text-white px-4 py-2 rounded">
Sačuvaj
</button>
</div>

</div>
</div>

<div id="toast" class="hidden fixed top-5 right-5 bg-green-600 text-white px-4 py-2 rounded">
<span id="toast-msg"></span>
</div>

<!-- UNIT MODAL -->
<div id="unitModal" class="hidden fixed inset-0 flex items-center justify-center z-50">
    <div class="bg-white p-6 rounded w-80">

        <h3 class="text-lg font-bold mb-3">Nova organizaciona jedinica</h3>

        <input type="text" id="unit_name" placeholder="Naziv"
            class="w-full border px-3 py-2 mb-3">

        <div class="mb-4">
            <label class="text-sm">Nadređena jedinica</label>

            <select id="parent_id" class="w-full border px-3 py-2 mt-1">
                <option value="">-- Nema (root) --</option>

                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="flex justify-end gap-2">
            <button onclick="closeUnitModal()">Zatvori</button>
            <button onclick="saveUnit()" class="bg-blue-600 text-white px-4 py-2 rounded">
                Sačuvaj
            </button>
        </div>

    </div>
</div>

<div id="employeeDetailModal" class="hidden fixed inset-0 flex items-center justify-center z-50">
    <div class="bg-white p-6 rounded w-[1000px] max-h-[80vh] overflow-y-auto">

        <h3 class="text-lg font-bold mb-4">Detalji zaposlenog</h3>

        <div id="employeeDetailContent" class="space-y-2 text-sm"></div>

        <div class="flex justify-end mt-4">
            <button onclick="closeDetailModal()">Zatvori</button>
        </div>

    </div>
</div><?php /**PATH C:\laragon\www\erp\resources\views/employees/partials/modals.blade.php ENDPATH**/ ?>