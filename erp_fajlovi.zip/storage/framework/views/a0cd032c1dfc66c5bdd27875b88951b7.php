<tr 
    onclick="toggleNode(event, this, <?php echo e($unit->id); ?>)"
    data-id="<?php echo e($unit->id); ?>"
    data-parent="<?php echo e($unit->parent_id); ?>"
    data-level="<?php echo e($level); ?>"
    class="cursor-pointer hover:bg-gray-100">
    <td class="p-2">
        <span class="bg-gray-100 px-2 py-1 rounded font-mono">
            <?php echo e($unit->code); ?>

        </span>
    </td>

    <td class="p-2">
        <?php echo str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $level); ?>

        <?php if($unit->children && $unit->children->count()): ?>
                <span class="toggle-icon mr-1 inline-block transition-transform">▼</span>
            <?php else: ?>
                <span class="inline-block w-3 mr-1"></span>
            <?php endif; ?>
        <span 
            class="unit-name"
            onclick="event.stopPropagation(); showEmployees(<?php echo e($unit->id); ?>)">
            <?php echo e($unit->name); ?>

        </span>
    </td>

    <td class="p-2 text-right space-x-2">

        <button 
                data-id="<?php echo e($unit->id); ?>"
                data-name="<?php echo e($unit->name); ?>"
                data-code="<?php echo e($unit->code); ?>"
                data-parent="<?php echo e($unit->parent_id); ?>"
                onclick="event.stopPropagation(); openEditUnitModal(this)"
                class="bg-yellow-400 px-2 py-1 rounded">
                ✏️ Izmena
        </button>

        <button 
            onclick="event.stopPropagation(); deleteUnit(<?php echo e($unit->id); ?>)"
            class="bg-red-500 text-white px-2 py-1 rounded">
            🗑
        </button>

</td>
</tr>

<?php if($unit->children): ?>
    <?php $__currentLoopData = $unit->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('organizational-units.partials.node', ['unit' => $child, 'level' => $level + 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\erp\resources\views/organizational-units/partials/node.blade.php ENDPATH**/ ?>