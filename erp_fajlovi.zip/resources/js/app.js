// resources/js/app.js
console.log("APP JS RADI");
import './bootstrap';

import { openEmployeeModal, closeEmployeeModal } from './modules/employee/employee-modal';

import flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
import { searchEmployees } from "./modules/employee/employee-search";
import { deleteEmployee } from "./modules/employee/employee-crud";
import { openDeleteConfirm } from "./modules/employee/employee-crud";
import { openEmployeeModal } from "./modules/employee/employee-modal";

document.addEventListener('click', function(e) {

    // DELETE
    const deleteBtn = e.target.closest('.delete-btn');
    if (deleteBtn) {
        e.stopPropagation();
        openDeleteConfirm(deleteBtn.dataset.id);
        return;
    }

    // ROW CLICK
    const row = e.target.closest('.employee-row');
    if (row) {
        openEmployeeModal(row.dataset.id);
    }

});

window.flatpickr = flatpickr;

window.openEmployeeModal = openEmployeeModal;
window.closeEmployeeModal = closeEmployeeModal;
window.searchEmployees = searchEmployees;
window.deleteEmployee = deleteEmployee;


import { openDeleteConfirm } from "./modules/employee/employee-crud";
import { openEmployeeModal } from "./modules/employee/employee-modal";

document.addEventListener('click', function(e) {

    // DELETE
    const deleteBtn = e.target.closest('.delete-btn');
    if (deleteBtn) {
        e.stopPropagation();
        openDeleteConfirm(deleteBtn.dataset.id);
        return;
    }

    // ROW CLICK
    const row = e.target.closest('.employee-row');
    if (row) {
        openEmployeeModal(row.dataset.id);
    }

});

let deleteId = null;

window.openDeleteConfirm = function(id) {
    deleteId = id;

    const modal = document.getElementById('deleteModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

window.closeDeleteModal = function() {
    const modal = document.getElementById('deleteModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

window.confirmDelete = function() {

    fetch(`/employees/${deleteId}`, {
        method: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        }
    })
    .then(() => {
        closeDeleteModal();
        location.reload();
    })
    .catch(() => alert('Greška pri brisanju'));

}