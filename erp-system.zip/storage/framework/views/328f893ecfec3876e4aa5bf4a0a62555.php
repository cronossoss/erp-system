<?php $__env->startSection('title', 'Radnici'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-white rounded shadow p-4">

    <div class="flex justify-between items-center mb-4">
        <h2 class="text-lg font-semibold">Lista zaposlenih</h2>

        <input 
            type="text" 
            id="searchInput"
            placeholder="Pretraga zaposlenih..."
            class="border px-3 py-2 rounded w-64"
            onkeyup="searchEmployees()">

        <button onclick="openModal()"
            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            + Dodaj zaposlenog
        </button>
    </div>

    <table class="w-full text-sm">
        <thead class="bg-gray-200 text-xs uppercase">
            <tr>
                <th class="p-3 text-left">Matični broj</th>
                <th class="p-3 text-left">Ime</th>
                <th class="p-3 text-left">Pozicija</th>
                <th class="p-3 text-left">Jedinica</th>
                <th class="p-3 text-left">Ugovor</th>
                <th class="p-3 text-right">Akcije</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr onclick="window.openEmployeeModal(<?php echo e($employee->id); ?>)"
                                    class="cursor-pointer hover:bg-gray-100">
                <td class="p-3"><?php echo e($employee->employee_number); ?></td>
                <td class="p-3"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></td>
                <td class="p-3"><?php echo e($employee->position); ?></td>
                <td class="p-3"><?php echo e($employee->organizationalUnit->name ?? '-'); ?></td>
                <td class="p-3"><?php echo e($employee->contract_type); ?></td>

                <td class="p-3 text-right space-x-2">

                    <button class="bg-yellow-400 px-2 py-1 rounded"
                        data-id="<?php echo e($employee->id); ?>"
                        data-first="<?php echo e($employee->first_name); ?>"
                        data-last="<?php echo e($employee->last_name); ?>"
                        data-position="<?php echo e($employee->position); ?>"
                        data-unit="<?php echo e($employee->organizational_unit_id); ?>"
                        data-employee_number="<?php echo e($employee->employee_number); ?>"
                        data-contract_type="<?php echo e($employee->contract_type); ?>"
                        onclick="event.stopPropagation(); openEditModal(this)">
                        ✏️
                    </button>

                    <button class="bg-red-500 text-white px-2 py-1 rounded"
                        data-id="<?php echo e($employee->id); ?>"
                        onclick="event.stopPropagation(); deleteEmployee(this)">
                        🗑
                    </button>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    

</div>

<div id="units-data"
     data-units='<?php echo json_encode($units, 15, 512) ?>'>
</div>

<?php echo $__env->make('employees.partials.modals', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('modals.employee-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\erp\erp-system\resources\views/employees/index.blade.php ENDPATH**/ ?>